<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DndModel extends Model
{
    public $timestamps = false;
}
